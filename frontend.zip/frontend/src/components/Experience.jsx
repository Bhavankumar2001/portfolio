import React from 'react';
import './Experience.css';

const Experience = () => {
  const experiences = [
    {
      id: 1,
      role: 'Software Engineer',
      company: 'Altrocks Tech Pvt Ltd',
      period: 'Oct 2023 - Present',
      location: 'Chennai, India',
      description: 'Developing enterprise-level applications with Java, Spring Boot, and SAP integrations. Leading payment processing systems and loyalty management solutions.'
    },
    {
      id: 2,
      role: 'Front End Developer',
      company: 'Hubsem Software Solutions',
      period: 'Jul 2023 - Sep 2023',
      location: 'Chennai, India',
      description: 'Built responsive e-commerce platforms using React.js, Redux, and modern web technologies. Implemented shopping cart functionality and dynamic routing.'
    }
  ];

  return (
    <section id="experience" className="experience">
      <div className="container">
        <h2 className="section-title">Experience</h2>
        <div className="experience-timeline">
          {experiences.map((exp) => (
            <div key={exp.id} className="timeline-item glass-panel">
              <div className="timeline-dot"></div>
              <div className="timeline-content">
                <div className="experience-header">
                  <span className="period">{exp.period}</span>
                  <span className="location">{exp.location}</span>
                </div>
                <h3 className="role">{exp.role}</h3>
                <h4 className="company">{exp.company}</h4>
                <p className="experience-description">{exp.description}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Experience;
