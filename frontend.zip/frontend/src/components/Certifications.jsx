import React from 'react';
import './Certifications.css';

function Certifications() {
  const certifications = [
    {
      title: 'Java FullStack Development',
      issuer: 'Qspider',
      date: '2022-2023',
      skills: 'Core Java, Spring Framework, HTML, CSS, Javascript, SQL',
      link: 'https://drive.google.com/file/d/1IV1yme8pnOToG2clXdr3h150PT-JQbQ2/view?usp=drive_link'
    },
    {
      title: 'React JS',
      issuer: 'Udemy',
      date: '2023',
      skills: 'React JSX, Class, Functions, Event Handling, Stylings, Routing, Hooks',
      link: null
    }
  ];

  return (
    <section id="certifications" className="certifications">
      <div className="container">
        <h2>Certifications</h2>
        <div className="certifications-list">
          {certifications.map((cert, index) => (
            <div key={index} className="cert-item">
              <div className="cert-badge">✓</div>
              <div className="cert-content">
                <h3>{cert.title}</h3>
                <div className="cert-meta">
                  <span className="cert-issuer">{cert.issuer}</span>
                  <span className="cert-dot">•</span>
                  <span className="cert-date">{cert.date}</span>
                </div>
              </div>
              {cert.link && (
                <a href={cert.link} target="_blank" rel="noopener noreferrer" className="cert-view">
                  View
                </a>
              )}
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

export default Certifications;