import React from 'react';
import './Education.css';

const Education = () => {
  return (
    <section id="education" className="education">
      <div className="container">
        <h2 className="section-title">Education & Certifications</h2>
        
        <div className="education-grid">
          <div className="education-card glass-panel">
            <h3>🎓 Education</h3>
            <div className="edu-item">
              <h4>Bachelor of Engineering in Computer Science</h4>
              <p className="institution">Bannari Amman Institute Of Technology, Sathyamangalam</p>
              <p className="year">2022</p>
              <p className="highlight">CGPA: 7.6/10</p>
              <p className="specialization">Specialization: Software Engineering & Web Technologies</p>
            </div>
          </div>
          
          <div className="education-card glass-panel">
            <h3>🏆 Certifications</h3>
            <div className="certifications-list">
              <div className="cert-item">
                <h4>Java FullStack Development</h4>
                <p className="platform">Platform: Qspider (2022-2023)</p>
                <p className="cert-description">Comprehensive training covering Core Java, Spring Framework, Hibernate, HTML, CSS, JavaScript, SQL, and MySQL</p>
                <div className="cert-skills">
                  <span className="skill-badge">Core Java</span>
                  <span className="skill-badge">Spring Framework</span>
                  <span className="skill-badge">Hibernate</span>
                  <span className="skill-badge">SQL</span>
                </div>
              </div>
              
              <div className="cert-item">
                <h4>React JS Development</h4>
                <p className="platform">Platform: Udemy (2023)</p>
                <p className="cert-description">Advanced React development including JSX, Class Components, Functional Components, Event Handling, Styling, Routing, and Hooks</p>
                <div className="cert-skills">
                  <span className="skill-badge">React JSX</span>
                  <span className="skill-badge">React Hooks</span>
                  <span className="skill-badge">React Router</span>
                  <span className="skill-badge">State Management</span>
                </div>
              </div>
              
              <div className="cert-item">
                <h4>SAP S/4HANA Integration</h4>
                <p className="platform">Platform: Self-Learning & Project Experience</p>
                <p className="cert-description">Hands-on experience with SAP OData services, API integration, and enterprise system connectivity</p>
                <div className="cert-skills">
                  <span className="skill-badge">SAP OData</span>
                  <span className="skill-badge">API Integration</span>
                  <span className="skill-badge">Enterprise Systems</span>
                </div>
              </div>
            </div>
          </div>
          
          <div className="education-card glass-panel">
            <h3>💼 Professional Skills</h3>
            <div className="skills-section">
              <div className="skill-category">
                <h4>Backend Development</h4>
                <div className="skill-tags">
                  <span className="skill-level expert">Java</span>
                  <span className="skill-level expert">Spring Boot</span>
                  <span className="skill-level advanced">REST APIs</span>
                  <span className="skill-level advanced">MySQL</span>
                  <span className="skill-level intermediate">Hibernate</span>
                </div>
              </div>
              
              <div className="skill-category">
                <h4>Frontend Development</h4>
                <div className="skill-tags">
                  <span className="skill-level advanced">React.js</span>
                  <span className="skill-level advanced">JavaScript</span>
                  <span className="skill-level intermediate">Redux</span>
                  <span className="skill-level intermediate">HTML5/CSS3</span>
                </div>
              </div>
              
              <div className="skill-category">
                <h4>Tools & Technologies</h4>
                <div className="skill-tags">
                  <span className="skill-level advanced">Git</span>
                  <span className="skill-level advanced">JasperReports</span>
                  <span className="skill-level intermediate">SAP S/4HANA</span>
                  <span className="skill-level intermediate">Postman</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Education;
