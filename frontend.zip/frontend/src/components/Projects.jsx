import React from 'react';
import './Projects.css';

const Projects = () => {
  const projects = [
    {
      id: 1,
      title: 'HDFC Bank Payments Integration',
      description: 'Secure SAP S/4HANA integration with HDFC Bank for outgoing payments processing using SSL certification.',
      tech: ['Java', 'Spring Boot', 'SAP S/4HANA', 'MySQL', 'AJAX', 'SSL/TLS'],
      status: 'Production',
      link: '#'
    },
    {
      id: 2,
      title: 'VKC & Violin API Integration',
      description: 'Invoice management system with dynamic PDF generation and SAP OData integration for manufacturing clients.',
      tech: ['Java', 'JasperReports', 'SAP OData API', 'Spring Boot', 'PDF Generation'],
      status: 'Production',
      link: '#'
    },
    {
      id: 3,
      title: 'Loyalty Points Management System',
      description: 'RESTful backend system for managing merchant and customer loyalty programs with advanced calculation algorithms.',
      tech: ['Java', 'Spring Boot', 'REST API', 'Swagger', 'MySQL', 'JWT Authentication'],
      status: 'Production',
      link: '#'
    },
    {
      id: 4,
      title: 'Web-Based E-commerce Application',
      description: 'Full-featured e-commerce platform with shopping cart, routing, and state management using React and Redux.',
      tech: ['React.js', 'Redux', 'React Router', 'JavaScript', 'HTML5', 'CSS3'],
      status: 'Completed',
      link: '#'
    }
  ];

  return (
    <section id="projects" className="projects">
      <div className="container">
        <h2 className="section-title">Featured Projects</h2>
        <div className="projects-grid">
          {projects.map((project) => (
            <div key={project.id} className="project-card glass-panel">
              <div className="project-header">
                <h3 className="project-title">{project.title}</h3>
                <span className={`project-status ${project.status.toLowerCase()}`}>{project.status}</span>
              </div>
              <p className="project-description">{project.description}</p>
              <div className="project-tech">
                <div className="tech-tags">
                  {project.tech.map((tech, index) => (
                    <span key={index} className="tech-chip">{tech}</span>
                  ))}
                </div>
              </div>
              <a href={project.link} className="project-link">
                View Details <span className="arrow">→</span>
              </a>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Projects;
