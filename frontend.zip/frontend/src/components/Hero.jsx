import React from 'react';
import './Hero.css';

const Hero = () => {
  return (
    <section id="home" className="hero">
      <div className="container hero-content">
        <h3 className="hero-greeting">Hello, I am Bhavan kumar V</h3>
        <h1 className="hero-title">
          A Dedicated <span className="highlight">Java Full-Stack Developer</span>
        </h1>
        <p className="hero-subtitle">
          With 2.5 years of experience in designing, developing, and maintaining web-based applications using Java, Spring Boot, Hibernate, and React.js.
        </p>
        <div className="hero-cta">
          <a href="#projects" className="btn btn-primary">View My Work</a>
          <a href="#contact" className="btn btn-outline" style={{marginLeft: '1rem'}}>Get In Touch</a>
        </div>
      </div>
    </section>
  );
};

export default Hero;
