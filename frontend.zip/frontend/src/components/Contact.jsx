import React, { useState } from 'react';
import './Contact.css';

const Contact = () => {
  const [formData, setFormData] = useState({ name: '', email: '', message: '' });
  const [status, setStatus] = useState('');

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setStatus('Sending...');
    try {
      const response = await fetch('https://portfolio-2-5j3o.onrender.com/api/contact', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(formData),
      });
      
      if (response.ok) {
        setStatus('Message sent successfully!');
        setFormData({ name: '', email: '', message: '' });
      } else {
        setStatus('Failed to send message.');
      }
    } catch (error) {
       console.error(error);
       setStatus('Error connecting to Server.');
    }
  };

  return (
    <section id="contact" className="contact">
      <div className="container">
        <h2 className="section-title">Let's Connect</h2>
        <div className="contact-content">
          <div className="contact-info glass-panel">
            <div className="social-connect">
              <h4>Connect With Me</h4>
              <div className="social-links">
                <a href="https://www.linkedin.com/in/bhavan-kumar-2b4a56205" 
                   target="_blank" 
                   rel="noopener noreferrer" 
                   className="social-link linkedin">
                  <span className="social-icon">💼</span>
                  LinkedIn Profile
                </a>
                <a href="https://github.com/Bhavankumar2001" 
                   target="_blank" 
                   rel="noopener noreferrer" 
                   className="social-link github">
                  <span className="social-icon">💻</span>
                  GitHub Profile
                </a>
                <a href="https://drive.google.com/file/d/18TnY0dWAq7YOvWTqRXPmiPMvINval3d4/view?usp=drive_link" 
                   target="_blank" 
                   rel="noopener noreferrer"
                   className="social-link resume">
                  <span className="social-icon">📄</span>
                  Download Resume
                </a>
              </div>
            </div>
          </div>
          
          <div className="contact-wrapper glass-panel">
            <h3>Send Me a Message</h3>
            <form onSubmit={handleSubmit} className="contact-form">
            <div className="form-group">
              <label htmlFor="name">Name</label>
              <input 
                type="text" 
                id="name" 
                name="name" 
                value={formData.name} 
                onChange={handleChange} 
                required 
                placeholder="Your full name"
              />
            </div>
            <div className="form-group">
              <label htmlFor="email">Email</label>
              <input 
                type="email" 
                id="email" 
                name="email" 
                value={formData.email} 
                onChange={handleChange} 
                required 
                placeholder="your.email@example.com"
              />
            </div>
            <div className="form-group">
              <label htmlFor="message">Message</label>
              <textarea 
                id="message" 
                name="message" 
                rows="5" 
                value={formData.message} 
                onChange={handleChange} 
                required
                placeholder="Tell me about your project or just say hello!"
              ></textarea>
            </div>
            <button type="submit" className="btn btn-primary submit-btn">
              Send Message
            </button>
            {status && <p className="status-message">{status}</p>}
            </form>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Contact;
