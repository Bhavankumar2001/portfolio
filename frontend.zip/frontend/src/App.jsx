import React from 'react';
import Navbar from './components/Navbar';
import Hero from './components/Hero';
import Experience from './components/Experience';
import Skills from './components/Skills';
import Certifications from './components/Certifications';
import Projects from './components/Projects';
import Contact from './components/Contact';
import './App.css';

function App() {
  return (
    <div className="app">
      <Navbar />
      <Hero />
      <Experience />
      <Skills />
      <Certifications />
      <Projects />
      <Contact />
      <footer>
        <p>© 2024 Bhavan Kumar V. All rights reserved.</p>
      </footer>
    </div>
  );
}

export default App;

